package com.gora.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private EditText input;
    private TextView status;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFF080D18);
        getWindow().setNavigationBarColor(0xFF080D18);
        prefs = getSharedPreferences("gora_settings", MODE_PRIVATE);
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) { ttsReady = true; tts.setLanguage(Locale.getDefault()); }
        });
        addMessage("GORA", "Namaste! Main GORA AI hoon. Main abhi offline phone commands aur configured Gemini AI support karta hoon. Mic dabakar bolo, ya message type karo.");
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(18, 18, 18, 12); page.setBackgroundColor(0xFF080D18);
        TextView title = new TextView(this); title.setText("◉  GORA AI"); title.setTextSize(25);
        title.setTextColor(0xFF70E1F5); title.setGravity(Gravity.CENTER_VERTICAL);
        page.addView(title, new LinearLayout.LayoutParams(-1, 54));
        status = new TextView(this); status.setText("PERSONAL ASSISTANT  •  OFFLINE COMMANDS READY");
        status.setTextColor(0xFF8B9BB4); status.setTextSize(10); page.addView(status);
        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(1); messages.setPadding(0,14,0,14);
        scroll.addView(messages); page.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this); input.setSingleLine(true); input.setHint("GORA se kuch poochho...");
        input.setHintTextColor(0xFF8290A5); input.setTextColor(0xFFFFFFFF);
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF70E1F5));
        row.addView(input, new LinearLayout.LayoutParams(0,54,1));
        Button mic = button("🎙"); row.addView(mic);
        Button send = button("SEND"); row.addView(send);
        page.addView(row);
        Button settings = button("AI SETTINGS / API KEY"); page.addView(settings);
        setContentView(page);
        send.setOnClickListener(v -> submit());
        input.setOnEditorActionListener((v, action, event) -> { submit(); return true; });
        mic.setOnClickListener(v -> startListening());
        settings.setOnClickListener(v -> settingsDialog());
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(0xFF70E1F5);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF17263A)); return b;
    }

    private void addMessage(String who, String text) {
        TextView bubble = new TextView(this);
        bubble.setText(who + "\n" + text); bubble.setTextSize(15); bubble.setTextColor(0xFFE8F0FA);
        bubble.setPadding(14,12,14,12); bubble.setBackgroundColor(who.equals("YOU") ? 0xFF17334A : 0xFF142033);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,6,0,6);
        messages.addView(bubble, lp);
    }

    private void submit() {
        String q = input.getText().toString().trim(); if (q.isEmpty()) return;
        input.setText(""); addMessage("YOU", q);
        String local = localCommand(q);
        if (local != null) { addMessage("GORA", local); speak(local); return; }
        String key = prefs.getString("gemini_key", "");
        if (key.isEmpty()) {
            String msg = "Is request ke liye internet AI chahiye. AI SETTINGS mein apni Gemini API key add karo. Basic phone commands offline kaam karte hain.";
            addMessage("GORA", msg); speak(msg); return;
        }
        status.setText("GORA IS THINKING...");
        worker.execute(() -> {
            String answer = askGemini(key, q);
            runOnUiThread(() -> { status.setText("PERSONAL ASSISTANT"); addMessage("GORA", answer); speak(answer); });
        });
    }

    // Offline commands are handled on-device; no network request is made.
    private String localCommand(String q) {
        String s = q.toLowerCase(Locale.ROOT);
        if (s.contains("time") || s.contains("samay") || s.contains("kitne baje")) return "Abhi " + new java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()) + " baj rahe hain.";
        if (s.contains("date") || s.contains("tarikh") || s.contains("aaj ka din")) return "Aaj " + new java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(new Date()) + " hai.";
        if (s.contains("battery") || s.contains(" बैटरी")) {
            BatteryManager bm = (BatteryManager)getSystemService(BATTERY_SERVICE);
            return "Battery level: " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + "%.";
        }
        if (s.contains("flashlight") || s.contains("torch") || s.contains("टॉर्च")) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, 42);
                return "Flashlight permission maangi hai. Permission allow karne ke baad command dobara bolo.";
            }
            try {
                CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
                String id = cm.getCameraIdList()[0];
                boolean on = prefs.getBoolean("torch", false);
                cm.setTorchMode(id, !on); prefs.edit().putBoolean("torch", !on).apply();
                return !on ? "Flashlight ON kar diya." : "Flashlight OFF kar diya.";
            } catch (Exception e) { return "Is device par flashlight control available nahi hua: " + e.getMessage(); }
        }
        if (s.contains("open youtube") || s.contains("youtube kholo")) return launchPackage("com.google.android.youtube", "YouTube");
        if (s.contains("open settings") || s.contains("settings kholo")) {
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); return "Phone Settings khol raha hoon."; }
            catch (Exception e) { return "Settings nahi khul paayi."; }
        }
        if (s.contains("open chrome") || s.contains("chrome kholo")) return launchPackage("com.android.chrome", "Chrome");
        if (s.equals("stop") || s.contains("stop speaking") || s.contains("chup")) { if (tts != null) tts.stop(); return "Theek hai, bolna rok diya."; }
        return null;
    }

    private String launchPackage(String pkg, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) return name + " app installed nahi hai ya launch nahi ho sakta.";
        startActivity(i); return name + " khol raha hoon.";
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { addMessage("GORA","Is phone par speech recognition service available nahi hai."); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 41); return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("LISTENING..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("PROCESSING..."); }
            public void onError(int e) { status.setText("PERSONAL ASSISTANT"); addMessage("GORA","Voice input nahi ho paaya. Dobara try karo."); }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                status.setText("PERSONAL ASSISTANT");
                if (r != null && !r.isEmpty()) { input.setText(r.get(0)); submit(); }
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle p) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "GORA se baat karein");
        recognizer.startListening(i);
    }

    private void settingsDialog() {
        EditText key = new EditText(this); key.setHint("Gemini API key"); key.setSingleLine(true);
        key.setInputType( android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        key.setText(prefs.getString("gemini_key",""));
        new android.app.AlertDialog.Builder(this).setTitle("Gemini API setup")
            .setMessage("Cloud AI request mein aapka message Google Gemini ko bheja jayega. API key private rakhein.")
            .setView(key)
            .setPositiveButton("SAVE", (d,w) -> { prefs.edit().putString("gemini_key", key.getText().toString().trim()).apply(); addMessage("GORA","API key is device par save ho gayi."); })
            .setNegativeButton("CANCEL", null).show();
    }

    private String askGemini(String key, String prompt) {
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + java.net.URLEncoder.encode(key,"UTF-8"));
            c = (HttpURLConnection)url.openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(30000);
            c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
            JSONObject part = new JSONObject().put("text", "You are GORA AI, a friendly concise multilingual assistant. Reply in the language used by the user. Be honest about limitations.\n\nUser: " + prompt);
            JSONObject body = new JSONObject().put("contents", new JSONArray().put(new JSONObject().put("parts", new JSONArray().put(part))));
            try(OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            InputStream stream = (c.getResponseCode() >= 200 && c.getResponseCode() < 300) ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buf = new byte[4096]; int n;
            while((n=stream.read(buf))!=-1) out.write(buf,0,n);
            JSONObject result = new JSONObject(out.toString("UTF-8"));
            if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) return "Gemini error: " + result.optJSONObject("error").optString("message","Request failed");
            return result.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text");
        } catch(Exception e) { return "AI connection error: " + e.getMessage(); }
        finally { if(c!=null) c.disconnect(); }
    }

    private void speak(String text) { if (ttsReady && tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gora_reply"); }
    @Override public void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        worker.shutdownNow(); super.onDestroy();
    }
}

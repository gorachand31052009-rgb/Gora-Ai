# GORA AI (starter build)

Package: `com.gora.ai`  
Minimum Android: 8.0 (API 26); intended to run on POCO M3 / Android 12.

## What this first build actually does
- Dark GORA AI chat screen.
- On-device date/time and battery replies.
- Flashlight toggle using Android CameraManager.
- Opens YouTube, Chrome (if installed), and Android Settings.
- Speech input through Android SpeechRecognizer (uses the phone's installed speech service; language availability varies).
- Reads replies aloud with Android TextToSpeech.
- Optional Gemini cloud chat after you enter your own API key.

## Important limitations
- Offline mode currently means the listed phone commands work without internet. It is **not** an offline large language model and cannot answer general knowledge questions offline.
- No always-on “Hey Gora” wake word: Android background microphone restrictions and battery impact make this unsuitable for a beginner-safe first build.
- Voice recognition may use Google or another configured speech service and may need internet.
- Gemini receives the message you submit when cloud AI is enabled. Do not submit secrets.
- API key storage in this starter is app-private preferences, not hardware-backed encrypted storage. Do not treat this as production security.
- Conversation history and personal memory are not yet implemented.
- Notification reading, reminders, file access, provider fallback, image/document understanding and streaming are not implemented in this stage.

## Build
The GitHub Actions workflow builds a debug APK on pushes to `main` and when manually run.
